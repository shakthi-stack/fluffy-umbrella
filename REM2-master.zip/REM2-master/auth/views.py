from remsite.models import AccountType, Client, Credentials, LCity, LState, Stakeholder
from django.http import request
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth


# Create your views here.

def login(request):
    if request.method=='POST':
        username=request.POST['username']
        password= request.POST['password']

        user=auth.authenticate(username=username,password=password)
        

        if user is not None:
            auth.login(request,user)
            return redirect("/")
        else:
            messages.info(request,'invalid creds')
            return redirect('login')

    else:
        return render(request,'login.html')


def register(request):

    if(request.method=='POST'):
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']
        cityx = request.POST['city']
        statex = request.POST['state']
        countryx = request.POST['country']
        dobx = request.POST['dob']
        occupationx = request.POST['occupation']
        atype = request.POST['atype']
        import random
        idx = random.randint(0,99999)
        

        
        if(password1!=password2):
            messages.info(request,'password not matching')
            return redirect('register')

        
        
        if LState.objects.filter(state=statex,country=countryx).exists():

            pass
        else:
            LState.objects.create(state=statex,country=countryx)
        
        if LCity.objects.filter(city=cityx,state=statex).exists():
            pass
        else:
            LCity.objects.create(city=cityx,state=LState.objects.get(state=statex,country=countryx))
        cityob=LCity.objects.get(city=cityx,state=LState.objects.get(state=statex,country=countryx))
        
        
        user=User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
        user.save()
       
     
        Stakeholder.objects.create(id=idx,fname=first_name,lname=last_name,city=cityob,dob=dobx,email=email)
        Credentials.objects.create(uname=username,password=password1,id=Stakeholder.objects.get(id=idx))
        Client.objects.create(c=Stakeholder.objects.get(id=idx),occupation=occupationx,account_type=AccountType.objects.get(account_type=atype))
        print('user_created')
        return redirect('login')




    else:
        return render(request,'register.html')

def logout(request):
    auth.logout(request)
    return redirect('/')


    
    