from django.apps import AppConfig


class RemsiteConfig(AppConfig):
    name = 'remsite'
