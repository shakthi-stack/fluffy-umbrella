from os import name
from django.urls import path
from django.urls.resolvers import URLPattern

from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('addInst',views.addInst,name='addInst'),
    path('viewInst',views.viewInst,name='viewInst'),
    path('account',views.account,name='account'),
    path('features',views.features,name='features'),
    path('plans',views.plans,name='plans'),
    path('aboutus',views.aboutus,name='aboutus'),
    path('contactus',views.contactus,name='contactus')
    ]
