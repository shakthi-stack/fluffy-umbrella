from typing import ContextManager

from django.contrib import messages
from remsite.models import Biomass, Client, Credentials, Geothermal, Hydro, Installations, LCity, LState, Solar, Stakeholder, Tidal, Wind
from django.shortcuts import redirect, render
from django.http import HttpResponse

def home(request):
    context={ "data":[1,2,3,4,5]}
    return render(request,"home.html",context)

def addInst(request):
    if(request.method=='POST'):
        type=request.POST['types']
        import random
        instidx = random.randint(0,99999)
        instidx=str(instidx)
        instidx=list(instidx)
        instidx[0]=type[0]
        instidx = "".join(instidx)
        loggedinUname=request.user.username
        loggedinID=Credentials.objects.get(uname=loggedinUname).id.id
        capacity = request.POST['cap']
        eff = request.POST['eff']
        loc = request.POST['loc']
        status = request.POST['status']
        curr=Installations.objects.create(inst_id=instidx,c=Stakeholder.objects.get(id=loggedinID),capacity=capacity,gps=loc,status=status,efficiency=eff)
        if(type=='solar'):
            qop = request.POST['qop']
            hum = request.POST['hum']
            cc = request.POST['cc']
            Solar.objects.create(inst=curr,quantity_of_panels=qop,cloud_cover=cc,humidity=hum)
        if(type=='wind'):
            rr = request.POST['rr']
            br = request.POST['br']
            ws = request.POST['ws']
            Wind.objects.create(inst=curr,rotorradius=rr,blade=br,windpseed=ws)
        if(type=='hydro'):
            river = request.POST['river']
            damn = request.POST['damn']
            height = request.POST['height']
            length = request.POST['length']
            Hydro.objects.create(inst=curr,river=river,height=height,length=length,damnname=damn)

        if(type=='geo'):
            flow = request.POST['flow']
            inttemp = request.POST['inttemp']
            Geothermal.objects.create(inst=curr,flowrate=flow,temp=inttemp)
        if(type=='tidal'):
            tidalpot = request.POST['tidalpot']
            dim = request.POST['dim']
            barragesize = request.POST['barragesize']
            Tidal.objects.create(inst=curr,tidalpotential=tidalpot,dimension=dim,barragesize=barragesize)
        if(type=='bio'):
            methane = request.POST['methane']
            conme = request.POST['conme']
            Biomass.objects.create(inst=curr,methane=methane,conversionmethod=conme)
        print("hello")
        messages.info(request,'Installation Created')

        return redirect('addInst') 
    else:
        return render(request,"addInst.html")

def viewInst(request):
    loggedinUname=request.user.username
    loggedinID=Credentials.objects.get(uname=loggedinUname).id.id
    inst=Installations.objects.filter(c=loggedinID)
    solar=None
    wind=None
    hydro=None
    tidal=None
    bio=None
    geo=None
    for i in inst:
        if(i.inst_id[0]=='s'):
            solar=Solar.objects.filter(inst=i.inst_id)
        if(i.inst_id[0]=='w'):
            wind=Wind.objects.filter(inst=i.inst_id)
        if(i.inst_id[0]=='h'):
            hydro=Hydro.objects.filter(inst=i.inst_id)
        if(i.inst_id[0]=='b'):
            bio=Biomass.objects.filter(inst=i.inst_id)
        if(i.inst_id[0]=='g'):
            geo=Geothermal.objects.filter(inst=i.inst_id)
        if(i.inst_id[0]=='t'):
            tidal=Tidal.objects.filter(inst=i.inst_id)

    context={ "inst": inst,"solar":solar,"wind":wind,"hydro":hydro,"bio":bio,"geo":geo,"tidal":tidal}
    return render(request,"viewInst.html",context)

def account(request):
    ident=request.user.username
    credid=Credentials.objects.get(uname=ident).id.id
    stake=Stakeholder.objects.get(id=credid)
    client=Client.objects.get(c=credid)
  

    context={"stake":stake,"client":client}
    return render(request,"account.html",context)

def features(request):
    return render(request,'features.html')
    
def plans(request):
    return render(request,'plans.html')
    
def aboutus(request):
    return render(request,'aboutus.html')
    
def contactus(request):
    return render(request,'contactus.html')